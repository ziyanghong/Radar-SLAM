/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * generateGlobalFeature_terminate.h
 *
 * Code generation for function 'generateGlobalFeature_terminate'
 *
 */

#ifndef GENERATEGLOBALFEATURE_TERMINATE_H
#define GENERATEGLOBALFEATURE_TERMINATE_H

/* Include files */
#include <cstddef>
#include <cstdlib>
#include "rtwtypes.h"
#include "generateGlobalFeature_types.h"

/* Function Declarations */
extern void generateGlobalFeature_terminate();

#endif

/* End of code generation (generateGlobalFeature_terminate.h) */
