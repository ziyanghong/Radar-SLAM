function showStreetViewAndGPS(lat_lon_traj, points, initial_gps)


%% google street view
figure;
headings = [45,135,225,315];
varargin.fov = 120;
varargin.key = 'AIzaSyArXN_gFzIDy131XzYE2HcSZwlt0qJIPP4';

for i = 1:numel(headings)
    varargin.heading = headings(i);
    
    varargout = get_google_streetview(lat_lon_traj(1,:),varargin);
    subplot(2,2,i);    
    imshow(varargout);   
    title(num2str(headings(i)));

    
end


%% gps trajectory on base map
figure;
name = 'openstreetmap';
url = 'a.tile.openstreetmap.org';
copyright = char(uint8(169));
attribution = copyright + "OpenStreetMap contributors";
addCustomBasemap(name,url,'Attribution',attribution)
% zoomLevel = 20;
% player = geoplayer(lat_lon(1,1),lat_lon(1,2),zoomLevel);
% player.Basemap = 'openstreetmap';
% plotRoute(player,lat_lon(:,1),lat_lon(:,2));
% plot(lat_lon(:,1),lat_lon(:,2),'bo');
gb = geobubble(lat_lon_traj(:,1),lat_lon_traj(:,2),'Basemap','openstreetmap');
gb.BubbleWidthRange = 8;
% webmap('Open Street Map');
% wmline(lat_lon(:,1),lat_lon(:,2),'Color','red','LineWidth', 2);


%% map points overlay on the map
heading = -1.13;
points_lats_lons = localCoordinate2gps(points, heading, initial_gps);
figure;
gb1 = geobubble(points_lats_lons(:,1),points_lats_lons(:,2),'Basemap','openstreetmap');
gb1.BubbleWidthRange = 3;
end