/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * generateGlobalFeature_data.cpp
 *
 * Code generation for function 'generateGlobalFeature_data'
 *
 */

/* Include files */
#include "generateGlobalFeature_data.h"
#include "generateGlobalFeature.h"
#include "rt_nonfinite.h"

/* Variable Definitions */
boolean_T isInitialized_generateGlobalFeature = false;

/* End of code generation (generateGlobalFeature_data.cpp) */
