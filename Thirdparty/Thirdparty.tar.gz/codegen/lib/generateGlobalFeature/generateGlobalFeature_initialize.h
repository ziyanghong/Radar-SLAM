/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * generateGlobalFeature_initialize.h
 *
 * Code generation for function 'generateGlobalFeature_initialize'
 *
 */

#ifndef GENERATEGLOBALFEATURE_INITIALIZE_H
#define GENERATEGLOBALFEATURE_INITIALIZE_H

/* Include files */
#include <cstddef>
#include <cstdlib>
#include "rtwtypes.h"
#include "generateGlobalFeature_types.h"

/* Function Declarations */
extern void generateGlobalFeature_initialize();

#endif

/* End of code generation (generateGlobalFeature_initialize.h) */
