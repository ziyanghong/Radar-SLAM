/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * generateGlobalFeature_data.h
 *
 * Code generation for function 'generateGlobalFeature_data'
 *
 */

#ifndef GENERATEGLOBALFEATURE_DATA_H
#define GENERATEGLOBALFEATURE_DATA_H

/* Include files */
#include <cstddef>
#include <cstdlib>
#include "rtwtypes.h"
#include "generateGlobalFeature_types.h"

/* Variable Declarations */
extern boolean_T isInitialized_generateGlobalFeature;

#endif

/* End of code generation (generateGlobalFeature_data.h) */
