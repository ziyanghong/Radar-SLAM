# Matlab

To run this code first compile SSC.cpp by running `mex SSC.cpp` in Matlab terminal.
Run `ANMS_Codes.m` to observe the performance.

We have tested with Matlab R2016b.
