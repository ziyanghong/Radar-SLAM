# Qmake

To run this code you need to use [Qt](https://www.qt.io/download/).

We have tested with qmake version 4.8.7, 5.5.1.
