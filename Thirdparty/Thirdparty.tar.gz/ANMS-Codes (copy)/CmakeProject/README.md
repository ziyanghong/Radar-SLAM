# Cmake

Compiling procedure:
```
mkdir build
cd build
cmake -DCMAKE_BUILD_TYPE=Release .. #for Release mode
cmake -DCMAKE_BUILD_TYPE=Debug .. #for Debug mode
make
```
