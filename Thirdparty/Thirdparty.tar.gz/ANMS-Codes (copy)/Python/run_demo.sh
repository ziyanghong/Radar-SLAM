python demo.py \
    --image_path='../Images/test.png' \
    --num_ret_points=750 \
    --tolerance=0.1 \
