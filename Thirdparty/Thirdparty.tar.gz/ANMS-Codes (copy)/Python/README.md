# Python

To run this code set parameters in run_demo.sh and execute `./run_demo.sh` from your terminal.

We have tested with Python 2.7.6 and OpenCV 2.4.8
