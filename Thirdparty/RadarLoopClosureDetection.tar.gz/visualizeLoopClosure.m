close all;
clear all;

% Visualize the loop closure of correct and wrong loop
% Choose between oxford dataset and ours
%
%%  Read files

paths = ['/home/hong/Documents/Oxford_Radar_RobotCar_Dataset/'...
    '2019-01-16-13-09-37-radar-oxford-10k/'];

% path = ['/home/hong/Documents/VW_RADAR_DATASET/Loops/2_2020-01-23-21-43-57/'];
% path = ['/home/hong/Documents/VW_RADAR_DATASET/Loops/0_2020-01-23-15-09-59/'];
% path = ['/home/hong/Documents/VW_RADAR_DATASET/Loops/3_2020-02-10-15-15-02/'];
% paths = string(paths);
% paths = [];
files = dir('/home/hong/Documents/Oxford_Radar_RobotCar_Dataset');
dirFlags = [files.isdir];
% Extract only those that are directories.
files = files(dirFlags);
for f = 3:size(files)
    path = strcat( files(f).folder , '/', files(f).name, '/');
    paths = [paths;path];
end
paths = string(paths);

%% main loop
for p = 1:size(paths)
    path = paths(p);
    image_path = strcat(path, 'radar_zfill_six/*.png');
    imagefiles = dir(image_path);
    descriptors_forward = zeros(size(imagefiles,1),192);
    %% Parameters
    threshold = 0.2;
    threads = 32;
    true_threshold = 5;
    % radar scan parameters
    if contains(path,'Oxford_Radar_RobotCar_Dataset')
        max_selected_distance = 87.5;
        radar_resolution = 0.0438;
        max_distance = 163;
    else
        max_selected_distance = 87.5;
        radar_resolution = 0.1736;
        max_distance = 100;
    end
    
    %% Compute descriptor
    parfor (i=1:size(imagefiles,1),threads)
        % for i=1
        imgName = strcat(imagefiles(i).folder, '/', imagefiles(i).name);
        img = imread(imgName);
        % figure; imshow(img);
        % Pre-process the polar image
        [point_cloud_forward, ~] = scan2pointCloud(img, max_selected_distance, radar_resolution, max_distance);
        % display the input data
        %     figure;grid on;hold on
        %     pcshow(point_Cloud);title('Input point cloud');
        
        % Compute forward descriptor
        [desM2DP, ~] = M2DP(point_cloud_forward);
        descriptors_forward(i,:) = desM2DP;
        

        
    end
    
    %% Compute distance matrix
    D_forward = pdist2(descriptors_forward,descriptors_forward);
    Similarity_forward = 1 - D_forward;
    
    
    %% Visualization
    close all;
    fig=figure; hold on;
    xlabel('x-axis')
    ylabel('y-axis')
    trajectory = animatedline;
    if contains(path,'Oxford_Radar_RobotCar_Dataset')
        gt_file = strcat(path,'gt/radar_odometry.csv');
        gt = readmatrix(gt_file);
        translation_xs = gt(1:size(gt,1),3);
        translation_ys = gt(1:size(gt,1),4);
        rotation_yaws = gt(1:size(gt,1),8);
        full_trajectory_gt = zeros(size(gt,1)+1, 2);
        RT_gt = eye(3,3);
        last_pose_gt = eye(3,3);
        for i = 1:size(gt,1)
            
            % gt pose
            RT_gt = [cos(rotation_yaws(i)) -sin(rotation_yaws(i)) translation_xs(i); sin(rotation_yaws(i)) cos(rotation_yaws(i)) translation_ys(i); 0 0 1];
            current_pose_gt = last_pose_gt*RT_gt;
            
            
            full_trajectory_gt(i+1,1) = current_pose_gt(1,3);
            full_trajectory_gt(i+1,2) = current_pose_gt(2,3);
            last_pose_gt = current_pose_gt;
            
            
            addpoints(trajectory, current_pose_gt(1,3), -current_pose_gt(2,3));
            drawnow
            
            % start from ith frame
            if i-600 > 0
                candidates = D_forward(i+1, 1:i-300);
                [dist_feat,index] = min(candidates);

                
                % Recall
                if dist_feat < threshold
                    %             if normailized_probability > 0.5
                    dist =  sqrt((current_pose_gt(1,3) - full_trajectory_gt(index,1))^2 ...
                        + (current_pose_gt(2,3) - full_trajectory_gt(index,2))^2 );
                    if dist < true_threshold
                        
                        plot( full_trajectory_gt(index,1), -full_trajectory_gt(index,2), ...
                            'Color', 'g', 'Marker', 'o' , 'DisplayName', 'True dectetion');
                        %                     disp(['Frame: ' num2str(i) ' has correct loop in Frame ' num2str(index)]);
                        plot([full_trajectory_gt(i,1) full_trajectory_gt(index,1)],[-full_trajectory_gt(i,2) -full_trajectory_gt(index,2)],'g');
                        
                    else
                        plot( full_trajectory_gt(index,1), -full_trajectory_gt(index,2), ...
                            'Color', 'r', 'Marker', 'x', 'DisplayName', 'False detection');
                        plot([full_trajectory_gt(i,1) full_trajectory_gt(index,1)],[-full_trajectory_gt(i,2) -full_trajectory_gt(index,2)],'r');
                        
                        disp(['Frame: ' num2str(i) ' has incorrect loop in Frame ' num2str(index)]);
                    end
                end
                
                %             title(strcat('normailized probability: ', num2str(normailized_probability)));
            end
        end
        filename = strcat(path, 'loopVisualization.png');
        saveas(fig,filename);

        
    else
        % Our dataset
        gt_file = strcat(path,'groundtruth_converted.txt');
        full_trajectory_gt = importdata(gt_file)    ;
        
        for i=1:size(full_trajectory_gt,1)
            
            addpoints(trajectory, full_trajectory_gt(i,1), full_trajectory_gt(i,2));
            drawnow
            frameTitle = strcat('Current frame: ', num2str(i));
            title(frameTitle);
            
            if i-300 > 0
                candidates = D_forward(i, 1:i-400);
                [dist_feat,index] = min(candidates);
                
                % Recall
                if dist_feat < threshold
                    dist =  sqrt((full_trajectory_gt(i,1) - full_trajectory_gt(index,1))^2 ...
                        + (full_trajectory_gt(i,2) - full_trajectory_gt(index,2))^2 );
                    % True or false
                    if dist < true_threshold
                        
                        plot( full_trajectory_gt(index,1), full_trajectory_gt(index,2), ...
                            'Color', 'g', 'Marker', 'o' , 'DisplayName', 'True dectetion');
                        %                     disp(['Frame: ' num2str(i) ' has correct loop in Frame ' num2str(index)]);
                        plot([full_trajectory_gt(i,1) full_trajectory_gt(index,1)],[full_trajectory_gt(i,2) full_trajectory_gt(index,2)],'g');
                        
                    else
                        plot( full_trajectory_gt(index,1), full_trajectory_gt(index,2), ...
                            'Color', 'r', 'Marker', 'x', 'DisplayName', 'False detection');
                        plot([full_trajectory_gt(i,1) full_trajectory_gt(index,1)],[ full_trajectory_gt(i,2) full_trajectory_gt(index,2)],'r');
                        
                        disp(['Frame: ' num2str(i) ' has incorrect loop in Frame ' num2str(index)]);
                    end
                    
                end
                
            end
        end
    end
end

% % Full trajectory
% figure;
% plot(full_trajectory_gt(:,1), -full_trajectory_gt(:,2), 'k', ...
%      'LineWidth',2);
% legend('gt');


%% clustering
% k = 10;
% idx = kmeans(descriptors_forward,k);
% figure
% gscatter(full_trajectory_gt(:,1), -full_trajectory_gt(:,2), idx(1:end-1));
% figure;
% histogram(idx)

%%
% max_pixel = floor(87.5/ 163 * size(img,2));
% img = img(:,1:max_pixel);
% t = 1: size(img,2);
% img(:,1:60) = 0;
% img(:,max_pixel:end) = 0;
%
% % subplot(2,1,1)
% x1_multipath = double(img(97,:));
% % figure; hold on;
% % plot(t,x1_multipath);
% figure; findpeaks(x1_multipath,t,'MinPeakProminence',8,'Annotate','extents','MinPeakDistance',100);
% % hold off;
% fftf(t, x1_multipath,[],5);
%
%
% x2_multipath = double(img(196,:));
% % plot(t,x_multipath);
% % fftf(t, x2_multipath);
% figure; findpeaks(x2_multipath,t,'MinPeakProminence',8,'Annotate','extents','MinPeakDistance',100);
%
% x_clean = double(img(19,:));
% fftf(t, x_clean);
% figure;
% findpeaks(x_clean,t,'MinPeakProminence',8,'Annotate','extents','MinPeakDistance',100);
%
%
% %% Histogram KL divergence
% figure;
% nbins = 8;
% subplot(2,2,1);h0 = histogram(img,nbins,'Normalization','probability'); title('Hist of image.');
% P0 = h0.Values;
%
% subplot(2,2,2);h1 = histogram(x_clean,nbins,'Normalization','probability'); title('Hist of clean scan.');
% P1 = h1.Values;
% X= 1:nbins;
% KL1 = kldiv(X',P0',P1');
%
%
% subplot(2,2,3);h2 = histogram(x1_multipath,nbins,'Normalization','probability'); title('Hist1 of multipath.');
% P2 = h2.Values;
% KL2 = kldiv(X',P0',P2');
%
% subplot(2,2,4);h3 = histogram(x2_multipath,nbins,'Normalization','probability'); title('Hist2 of multipath.');
% P3 = h3.Values;
% KL3 = kldiv(X',P0',P3');
% % subplot(2,1,2);
% % plot(t,x_clean);