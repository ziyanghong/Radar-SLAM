function [pointCloudForward, pointCloudOpposite]= scan2pointCloud(img, max_selected_distance,radar_resolution, max_distance )

% input:
% img: polar image
% max_selected_distance: maximum distance chosen by user in meters
% radar_resolution: m / pixel
% max_distance: maximum distance for each azimuth sacn in meters

max_pixel = floor(max_selected_distance/ max_distance * size(img,2));


img = img(:,1:max_pixel);
t = 1: size(img,2);
if max_pixel > 600
    car_reflection = 60;
else
    car_reflection = 30;
end

img(:,1:car_reflection) = 0;
img(:,max_pixel:end) = 0;

allocated_memoery = 10000000;
% allocated_memoery = 2000; % defalut

pointCloudForward = zeros(allocated_memoery,3);
pointCloudOpposite = zeros(1,3);
% tic
counter = 1;
for i=1:size(img,1)
    scan = double(img(i,:));
    [pks,locs]= findpeaks(scan,t,'MinPeakProminence',8,'Annotate','extents','MinPeakDistance',50);
    peaks_mean = mean(pks); 
    peaks_std = std(pks);
    for j=1:size(pks,2)
        pk = pks(j);
        if (pk > peaks_mean + peaks_std)
            theta =  pi/2 - i* 2 * pi / 400;
            x = locs(j)*radar_resolution*cos(theta);
            y = locs(j)*radar_resolution*sin(theta);
            z = 1;
            % Forward view
            point = [x y z];
            pointCloudForward(counter,:) = point; 
            
            counter = counter + 1;

        end
    end
end
pointCloudForward = pointCloudForward(1:counter,:);

% toc
end