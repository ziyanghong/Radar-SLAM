%#codegen
function [feature,point_cloud_forward] = generateGlobalFeature(img, max_selected_distance, range_resolution, max_distance)

% Pre-process the polar image
[point_cloud_forward, ~] = scan2pointCloud(img, max_selected_distance,range_resolution,max_distance);

% Compute forward descriptor
[feature, ~] = M2DP(point_cloud_forward);

